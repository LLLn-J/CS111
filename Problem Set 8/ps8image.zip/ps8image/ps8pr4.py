#
# ps8pr4.py (Problem Set 8, Problem 4)
#
# Image processing with loops and image objects
#
# Computer Science 111
#

from cs111png import *

